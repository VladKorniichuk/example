package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ShoppingCartEmptyPage extends TopPart {

    @FindBy(xpath = "//h1[text()='Shopping Cart']")
    private WebElement shoppingCartLabel;

    @FindBy(xpath = "//p[text()='Your shopping cart is empty!']")
    private WebElement emptyCartLabel;

    @FindBy(xpath = "//a[text()='Continue']")
    private WebElement continueButton;

    public ShoppingCartEmptyPage(WebDriver driver) {
        super(driver);
    }

    public String getShoppingCartLabelText() {
        return shoppingCartLabel.getText();
    }

    public String getEmptyCartLabelText() {
        return emptyCartLabel.getText();
    }

    public void clickContinueButton() {
        continueButton.click();
    }
}
