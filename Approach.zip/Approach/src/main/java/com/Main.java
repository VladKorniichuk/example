package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.opencart.com/index.php?route=checkout/cart&language=en-gb");
        ShoppingCartEmptyPage shoppingCartEmptyPage = new ShoppingCartEmptyPage(driver);
        System.out.println(shoppingCartEmptyPage.getShoppingCartLabelText());
        System.out.println(shoppingCartEmptyPage.getEmptyCartLabelText());
        shoppingCartEmptyPage.clickContinueButton();
        driver.quit();
    }
}
