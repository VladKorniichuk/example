package com;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class TopPart {
    protected WebDriver driver;

    public TopPart(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
}